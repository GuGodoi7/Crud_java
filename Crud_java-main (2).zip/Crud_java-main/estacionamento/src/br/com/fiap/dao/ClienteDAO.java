package br.com.fiap.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


import br.com.fiap.bean.Cliente;

public class ClienteDAO {
	private Connection con;

	public Connection getCon() {
		return con;
	}

	public void setCon(Connection con) {
		this.con = con;
	}
	
	public String inserir(Cliente cliente) {
		String sql = "insert into carro(placa,cor,descricao)values(?,?,?)";
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setString(1, cliente.getPlaca());
			ps.setInt(2, cliente.getIdCliente());
			ps.setInt(3, cliente.getNomeCliente());
			if (ps.executeUpdate() > 0) {
				return "Inserido com sucesso.";
			} else {
				return "Erro ao inserir";
			}
		} catch (SQLException e) {
			return e.getMessage();
		}
	}	
	public String alterar(Cliente cliente) {
		String sql = "update cliente ";
		sql += "set idCliente = ?, nomeCliente = ?";
		sql += "where placa = ?";
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setString(3, cliente.getPlaca());
			ps.setInt(1, cliente.getIdCliente());
			ps.setInt(2, cliente.getNomeCliente());
			if (ps.executeUpdate() > 0) {
				return "Atualizado com sucesso.";
			} else {
				return "Erro ao Alterar";
			}
		} catch (SQLException e) {
			return e.getMessage();
		}
	}
	public String excluir(Cliente cliente) {
		String sql = "delete from cliente where placa = ?";
		
		try {
			PreparedStatement ps = getCon().prepareStatement(sql);
			ps.setString(1, cliente.getPlaca());
			if (ps.executeUpdate() > 0) {
				return "Excluido com sucesso.";
			} else {
				return "Excluido ao Alterar";
			}
		} catch (SQLException e) {
			return e.getMessage();
		}
	}
	

}
