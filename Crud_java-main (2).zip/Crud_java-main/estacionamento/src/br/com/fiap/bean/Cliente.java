package br.com.fiap.bean;

public class Cliente {
	private int idCliente;
	private int nomeCliente;
	private String placa;
	
	public int getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}
	public int getNomeCliente() {
		return nomeCliente;
	}
	public void setNomeCliente(int nomeCliente) {
		this.nomeCliente = nomeCliente;
	}
	public String getPlaca() {
		return placa;
	}
	public void setPlaca(String placa) {
		this.placa = placa;
	}
	
	

}
